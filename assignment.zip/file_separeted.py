#question b

def csc_217_separated():
    csc_217_class = open("CSC_217_attendance_ week1.txt")
    separated = open("csc_217_computer.txt", "w")
    for lines in csc_217_class:
        if "B135" in lines:
            separated.write(lines)
        separated.close()
    separated = open("CSC_217_IT.txt", "w")
    for lines in separated:
        if "B141" in lines:
            separated.write(lines)
    separated.close()
    csc_217_class.close()


csc_217_separated()


